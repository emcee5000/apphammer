<?php
if(isset($_POST['email'])) {
     
    // CHANGE THE TWO LINES BELOW
    $email_to = "mmclarke@apphammer.co";
     
    $email_subject = "Contact from Website";
     
     
    function died($error) {
        // your error code can go here
        echo "Yikes, we have an problem!  No big deal though, just take a look at the following and fix it up";
        echo $error."<br /><br />";
        die();
    }
     
    // validation expected data exists
    if(!isset($_POST['first-name']) ||
        !isset($_POST['last-name']) ||
        !isset($_POST['email']) ||
        !isset($_POST['phone']) ||
        !isset($_POST['company']) ||
        !isset($_POST['message'])) {
        died('Yikes, we have an problem!  No big deal though, just take a look at the following and fix it up.');       
    }
     
    $first-name = $_POST['first-name']; // required
    $last-name = $_POST['last-name']; // required
    $email = $_POST['email']; // required
    $phone = $_POST['telephone']; // not  required
    $company = $_POST['company']; // not required
    $message = $_POST['comments']; // required
     
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
  if(!preg_match($email_exp,$email)) {
    $error_message .= 'Looks like something is wrong with the email address.<br />';
  }
    $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$first-name)) {
    $error_message .= 'We are informal around here, your first name is importnat to us!<br />';
  }
  if(!preg_match($string_exp,$last-name)) {
    $error_message .= 'Looks like we have a problem with your last name.<br />';
  }
  if(strlen($message) < 2) {
    $error_message .= 'We need to know how we can help you, otherwise we are both spinning our wheels.<br />';
  }
  if(strlen($error_message) > 0) {
    died($error_message);
  }
    $email_message = "You got one!!!  Soemone filled our the form on our website.  Details below. \n\n";
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
     
    $email_message .= "First Name: ".clean_string($first-name)."\n";
    $email_message .= "Last Name: ".clean_string($last-name)."\n";
    $email_message .= "Email: ".clean_string($email)."\n";
    $email_message .= "Telephone: ".clean_string($phone)."\n";
    $email_message .= "Company: ".clean_string($company). "\n";
    $email_message .= "Message: ".clean_string($message)."\n";
     
     
// create email headers
$headers = 'From: '.$email."\r\n".
'Reply-To: '.$email."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>
 
<!-- place your own success html below -->
 
Thanks, we got it!  We'll be in touch.  
 
<?php
}
die();
?>